	var lbvast = ["https://vast.logobar.tv/lbvast.php?cid=90kre6s5c66m"];
