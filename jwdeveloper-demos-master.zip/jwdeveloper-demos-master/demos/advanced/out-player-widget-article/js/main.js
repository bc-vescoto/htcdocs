jwplayer('widget-video-player').setup({
  playlist: 'https://cdn.jwplayer.com/v2/media/RDn7eg0o',
  autostart: false
});

jwplayer('ads-video-player').setup({
  playlist: 'https://cdn.jwplayer.com/v2/media/z0nRtVrT',
  autostart: false,
  width: '320',
  height: '195'
});
