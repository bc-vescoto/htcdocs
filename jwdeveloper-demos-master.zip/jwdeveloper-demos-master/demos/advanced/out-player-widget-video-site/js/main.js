jwplayer('widget-video-player').setup({
  playlist: 'https://cdn.jwplayer.com/v2/media/8TbJTFy5',
  autostart: false,
  aspectratio: '16:9',
  width: '100%'
});

