jwplayer("player").setup({
	"file": "https://wowzaec2demo.streamlock.net/vod-multitrack/_definst_/smil:ElephantsDream/ElephantsDream.smil/playlist.m3u8",
	"title": "Wowza - Elephants Dream",            
	"hlslabels": {
        "331": "Lowest",
        "688": "Low",
        "1427": "Medium",
        "2962": "High"
    }
});