jwplayer("player").setup({
        file: '//ams-samplescdn.streaming.mediaservices.windows.net/c1275bed-9977-40ca-bb27-91bc783c040b/sintel_trailer-1080p.ism/manifest(format=m3u8-aapl)',
        androidhls:"true",
        aestoken:"Bearer%3durn%253amicrosoft%253aazure%253amediaservices%253acontentkeyidentifier%3d8ca714da-5404-4617-9fc2-3ea58d88667f%26Audience%3durn%253atest%26ExpiresOn%3d2281559228%26Issuer%3dhttp%253a%252f%252ftestacs.com%252f%26HMACSHA256%3dpimqYZll8uFqSYYFX6AOxAbHH6epEgsn1Y%252f%252bJnOdCLc%253d",
        });